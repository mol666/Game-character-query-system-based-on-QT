#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QTreeWidget>
#include <QDebug>
#include <QString>
#include <QIcon>
#include <QCompleter>
#include <QStringListModel>
#include <QComboBox>
#include <string>
#include <QMessageBox>
#include <cstring>
#include <QMovie>
using namespace Qt;

//基础角色
class Origin
{
private:
public:
    virtual int show_feature(QString Name, int Buff=0, int Weapon=0)
    {
        if(Name=="马里奥")
            return 1;
        else if(Name=="路易吉")
            return 2;
        else if(Name=="奇诺比奥")
            return 3;
        else if(Name=="奇诺比可")
            return 4;
        else return 0;
    }
protected:
};


class Single_Buff :virtual public Origin
{
private:
public:
    virtual int show_feature(QString Name, int Buff, int Weapon)
    {
        if(Name=="马里奥")
        {
            return 10+Buff;
        }
        else return 0;
    }
protected:
};

class Single_Weapon :virtual public Origin
{
private:
public:
    virtual int show_feature(QString Name, int Buff, int Weapon)
    {
        if(Name=="马里奥")
        {
            return 20+Weapon;
        }
        else return 0;
    }
protected:
};

class Buff_n_Weapon :public Single_Buff, public Single_Weapon
{
private:
public:
    virtual int show_feature(QString Name, int Buff, int Weapon)
    {
        if (Name=="马里奥")
        {
            if(Weapon==1&&(Buff==1||Buff==2||Buff==4)) return 30+Buff;
        }else return 0;
    }
};






MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //设计标题
    this->setWindowTitle("超级马里奥世界-角色查询");
    ui->Title_label->setScaledContents(true);
    ui->Title_label->setPixmap(QPixmap(":/Image/title.png"));
    ui->Title_label->resize(ui->widget_2->size());
    //初始默认人物图像，马里奥
    ui->Image_label->setScaledContents(true);
    ui->Image_label->setPixmap(QPixmap(":/Image/Small-mario.png"));
    ui->Image_label->resize(ui->widget_3->size());
    //状态栏下拉
    ui->Buff_comboBox->addItem("无状态");
    ui->Buff_comboBox->addItem("超级蘑菇");
    ui->Buff_comboBox->addItem("火之花");
    ui->Buff_comboBox->addItem("无敌星");
    ui->Buff_comboBox->addItem("斗篷羽毛");
    ui->Buff_comboBox->addItem("气球");
    //装备栏下拉
    ui->Weapon_comboBox->addItem("无装备");
    ui->Weapon_comboBox->addItem("耀西");
    ui->Weapon_comboBox->addItem("乌龟头盔");
    ui->Weapon_comboBox->addItem("乌龟底座");

    //历史记录功能
    ui->pushButton->setStyleSheet("background-color: rgba(94%,97%,100%,80%)");
    QStringList history;
    QStringListModel histModel;
    histModel.setParent(this);
    histModel.setStringList(history);


    //搜索框
    connect(ui->pushButton,&QPushButton::clicked,[=]()mutable{

        //自动补全搜索历史
        QString text = ui->Search_line->text();
        history<<text;
        QCompleter *completer = new QCompleter(history, this);
        completer->setCaseSensitivity(Qt::CaseSensitive);
        ui->Search_line->setCompleter(completer);


        //接受下拉框的消息（状态栏）
        int Buff_Selected = ui->Buff_comboBox->currentIndex();
        //接受信息（装备栏）
        int Weapon_Selected = ui->Weapon_comboBox->currentIndex();

        Origin *p;
        //是否有这个角色，0没有，1有
        int acceptedFlag = 0;
        int get_p_num=0;
        if(text=="马里奥")
        {
            if(Weapon_Selected==0)
            {
                acceptedFlag=1;
                if(Buff_Selected==0)
                {
                    Origin Mario;
                    p=&Mario;
                }else
                {
                    Single_Buff Mario;
                    p=&Mario;
                }
            }else
            {
                if(Weapon_Selected==1&&(Buff_Selected==1||Buff_Selected==2||Buff_Selected==4))
                {
                    acceptedFlag=1;
                    Buff_n_Weapon Mario;
                    p=&Mario;
                }else if(Weapon_Selected&&Buff_Selected==0)
                {
                    acceptedFlag=1;
                    Single_Weapon Mario;
                    p=&Mario;
                }else acceptedFlag=0;
            }


        }else if(text=="奇诺比奥"&&Weapon_Selected==0&&Buff_Selected==0)
        {
            acceptedFlag=1;
            Origin Kinopio;
            p=&Kinopio;
        }else if(text=="奇诺比可"&&Weapon_Selected==0&&Buff_Selected==0)
        {
            acceptedFlag=1;
            Origin Kinopiko;
            p=&Kinopiko;
        }else if(text=="路易吉"&&Weapon_Selected==0&&Buff_Selected==0)
        {
            acceptedFlag=1;
            Origin Mario;
            p=&Mario;
        }else acceptedFlag=0;

        if(acceptedFlag==0)
        {
            QMessageBox::warning(this,"Sorry!","没有来得及收录这个角色！");
            ui->Search_line->clear();
            ui->Image_label->setPixmap(QPixmap(":/Image/Small-mario.png"));
            ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
            ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
        }
        if(acceptedFlag==1)
        {

            get_p_num=p->show_feature(text, Buff_Selected, Weapon_Selected);
            qDebug()<<get_p_num;

            ui->Used_buff_label->setScaledContents(true);
            ui->Used_weapon_label->setScaledContents(true);

            if(get_p_num/10==0)
            {
                switch (get_p_num)
                {
                case 1:ui->Image_label->setPixmap(QPixmap(":/Image/Mario.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                case 2:ui->Image_label->setPixmap(QPixmap(":/Image/Luigi.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                case 3:ui->Image_label->setPixmap(QPixmap(":/Image/Kinopio.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                case 4:ui->Image_label->setPixmap(QPixmap(":/Image/Kinopiko.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                default:break;
                }
            }else if(get_p_num/10==1)
            {
                switch (get_p_num%10)
                {
                case 1:ui->Image_label->setPixmap(QPixmap(":/Image/mario_supermushroom.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/MushroomSMW.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                case 2:ui->Image_label->setPixmap(QPixmap(":/Image/mario_flower.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/FlowerSMW.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                case 3:ui->Image_label->setPixmap(QPixmap(":/Image/mario_star.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/SMW_Star.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                case 4: ui->Image_label->setPixmap(QPixmap(":/Image/mario_fly.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/Feather.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                case 5:ui->Image_label->setPixmap(QPixmap(":/Image/mario_ballon.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/P-Balloon_SMW.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/blank.png"));
                    break;
                default:break;
                }
            }else if(get_p_num/10==2)
            {
                switch (get_p_num%10)
                {
                case 1:ui->Image_label->setPixmap(QPixmap(":/Image/mario_yoshi.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/Green_Yoshi.png"));
                    break;
                case 2:ui->Image_label->setPixmap(QPixmap(":/Image/mario_toukui.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/toukui.png"));
                    break;
                case 3:ui->Image_label->setPixmap(QPixmap(":/Image/mario_dike.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/blank.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/dizuo.png"));
                    break;
                default:break;
                }
            }else if(get_p_num/10==3)
            {
                switch (get_p_num%10)
                {
                case 1:ui->Image_label->setPixmap(QPixmap(":/Image/mario_mushroom_yoshi.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/MushroomSMW.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/Green_Yoshi.png"));
                    break;
                case 2:ui->Image_label->setPixmap(QPixmap(":/Image/mario_flower_yoshi.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/FlowerSMW.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/Green_Yoshi.png"));
                    break;
                case 4:ui->Image_label->setPixmap(QPixmap(":/Image/mario_fly_yoshi.png"));
                    ui->Used_buff_label->setPixmap(QPixmap(":/Image/Feather.png"));
                    ui->Used_weapon_label->setPixmap(QPixmap(":/Image/Green_Yoshi.png"));
                    break;
                default:break;
                }
            }
            ui->Image_label->resize(ui->widget_3->size());
            ui->Used_buff_label->resize(ui->widget_4->size());
            ui->Used_weapon_label->resize(ui->widget_4->size());
            QMessageBox::information(this, "Success！", "查询成功！");
        }

    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

